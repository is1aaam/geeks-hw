let timeLeft = 300;

const timer = setInterval(() => {
  const minutesLeft = Math.floor(timeLeft / 60);
  let secondsLeft = timeLeft % 60;

  if (secondsLeft < 10) {
    secondsLeft = "0" + secondsLeft;
  }
  const timerDisplay = document.getElementById("timer");
  timerDisplay.innerHTML = `${minutesLeft}:${secondsLeft}`;

  timeLeft--;

  if (timeLeft % 60 === 0) {
    const minutesPassed = Math.floor((300 - timeLeft) / 60);
    alert(`Прошла минута! Осталось  ${5 - minutesPassed} минут`);
  }

  if (timeLeft < 0) {
    clearInterval(timer);
    alert("Время вышло!");
  }
}, 1000);

